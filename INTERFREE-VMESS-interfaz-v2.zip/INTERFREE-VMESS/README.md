# INTERFREE VPN

Proyecto Android independiente para cliente VMess.

## Estado actual
- Interfaz Jetpack Compose rediseñada con marca INTERFREE VPN.
- Sección MI CUENTA con campos Android nativos y almacenamiento local.
- Indicadores de ping y velocidad aún sin telemetría.
- El servicio VPN sigue siendo una plantilla: Xray Core/libXray todavía no está integrado. La interfaz no simula una conexión activa.

## Compilación
El workflow de GitHub Actions genera un APK debug. Instalar el APK no implica que VMess esté operativo hasta completar y probar la integración del motor Xray.
