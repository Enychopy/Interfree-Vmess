# INTERFREE VMESS

Proyecto Android de INTERFREE VPN basado en la interfaz V2 original.

## Compilación

El workflow de GitHub Actions prepara el motor Android oficial de XTLS:

1. Descarga `XTLS/libXray` en un directorio temporal del runner.
2. Ejecuta el script de compilación Android recomendado por el proyecto oficial.
3. Copia `libXray.aar` a `app/libs/`.
4. Compila el APK e incluye el AAR como dependencia local.
5. Publica el APK y el AAR como artefactos separados de la ejecución.

No es necesario subir manualmente el AAR al repositorio.

## Estado funcional importante

Esta entrega prepara la compilación e inclusión de la biblioteca nativa. **No significa que el túnel VMess ya esté operativo**: `InterfreeVpnService.kt` todavía requiere completar la integración de `VpnService`, el controlador `protect()` de Android, la configuración JSON VMess y el ciclo `runXray` / `stopXray`. No se debe presentar el estado de la interfaz como una conexión real hasta completar y probar esas piezas.

La configuración debe tomar el UUID del campo MI CUENTA en tiempo de ejecución. No se debe insertar ningún UUID privado en el código, APK o repositorio.

## Configuración de servidor conocida

- Transporte: WebSocket
- Puerto: 443
- Ruta: `/`
- TLS: activado
- SNI: `www.googletagmanager.com`
- Host WebSocket: `interfree-vpn.duckdns.org`
- Fingerprint: `chrome`

No se guardan UUID de clientes ni credenciales del panel 3X-UI en este repositorio.
